#!/bin/bash
cd $HOME/levanter
npm start .
