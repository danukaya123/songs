#!/bin/bash
cd $HOME/mystic
npm start .
