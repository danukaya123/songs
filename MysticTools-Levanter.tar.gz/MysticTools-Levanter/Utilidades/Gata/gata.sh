#!/bin/bash
cd $HOME/gata
npm start .
